/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./rdw/index.ts":
/*!**********************!*\
  !*** ./rdw/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.rdw = void 0;\nvar rdw = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function rdw() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  rdw.prototype.getCar = function (license) {\n    var base_url = \"http://opendata.rdw.nl/api/id/m9d7-ebf2.json?$where=kenteken='\";\n    var url = base_url + license + \"'\";\n    var data = '';\n    var div = document.getElementById(\"RDW-INFO\");\n    var xmlhttp = new XMLHttpRequest();\n    xmlhttp.onreadystatechange = function () {\n      if (this.readyState == 4 && this.status == 200) {\n        var res = JSON.parse(this.responseText);\n        data = res[0];\n        var vhcl = JSON.parse(JSON.stringify(data, null, 2));\n        // setting car values:\n        var car = vhcl.merk + ' ' + vhcl.handelsbenaming;\n        var soort = vhcl.inrichting;\n        var hoogte = vhcl.hoogte_voertuig;\n        var kleur = vhcl.eerste_kleur;\n        var kleur2 = vhcl.tweede_kleur;\n        var wok = vhcl.wacht_op_keuren;\n        var wam = vhcl.wam_verzekerd;\n        var cyls = vhcl.aantal_cilinders;\n        var volume = vhcl.cilinderinhoud;\n        var lege_massa = vhcl.massa_ledig_voertuig;\n        var massa_klaar = vhcl.massa_rijklaar;\n        var max_massa = vhcl.toegestane_maximum_massa_voertuig;\n        var lengte = vhcl.lengte;\n        var breedte = vhcl.breedte;\n        // Tenaamstelling\n        var dateString1 = vhcl.datum_tenaamstelling;\n        var year1 = dateString1.substring(0, 4);\n        var month1 = dateString1.substring(4, 6);\n        var day1 = dateString1.substring(6, 8);\n        var tenaamstelling = new Date(year1, month1 - 1, day1);\n        // APK\n        var dateString2 = vhcl.vervaldatum_apk;\n        var year2 = dateString1.substring(0, 4);\n        var month2 = dateString1.substring(4, 6);\n        var day2 = dateString1.substring(6, 8);\n        var APK = new Date(year2, month2 - 1, day2);\n        // Render\n        div.innerText = \"Auto: \" + car + '\\n';\n        div.innerText += \"Soort: \" + soort + '\\n';\n        div.innerText += \"Afmetingen (L x B x H): \" + lengte + ' x ' + breedte + ' x ' + hoogte + '\\n';\n        div.innerText += \"WAM: \" + wam + '\\n';\n        div.innerText += \"WOK: \" + wok + '\\n';\n        div.innerText += \"APK Vervaldatum: \" + APK + '\\n';\n        div.innerText += \"Laatste tenaamstelling: \" + tenaamstelling + '\\n';\n        div.innerText += \"Massa ledig voertuig: \" + lege_massa + ' kg' + '\\n';\n        div.innerText += \"Massa Rijklaar: \" + massa_klaar + ' kg' + '\\n';\n        div.innerText += \"Totale maximum massa: \" + max_massa + ' kg' + '\\n';\n        div.innerText += \"Cylinders en Inhoud: \" + cyls + \" cylinders, \" + volume + \" cm3\" + '\\n';\n        div.innerText += \"Primaire kleur: \" + kleur + '\\n';\n        div.innerText += \"Secundaire kleur: \" + kleur2 + '\\n';\n        //div.innerText = JSON.stringify(data, null, 2)\n      }\n    };\n\n    xmlhttp.open(\"GET\", url, true);\n    xmlhttp.send();\n  };\n  rdw.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._container = document.createElement(\"div\");\n    container.appendChild(this._container);\n    container.id = \"RDW-INFO\";\n    var licenseplate = context.parameters.vehicle_registration.raw;\n    this.getCar(licenseplate);\n    //const url = \"http://opendata.rdw.nl/api/id/m9d7-ebf2.json?$where=kenteken='63BKP7'\"\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  rdw.prototype.updateView = function (context) {\n    var licenseplate = context.parameters.vehicle_registration.raw;\n    this.getCar(licenseplate);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  rdw.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  rdw.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return rdw;\n}();\nexports.rdw = rdw;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./rdw/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./rdw/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('rdw.rdw', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.rdw);
} else {
	var rdw = rdw || {};
	rdw.rdw = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.rdw;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}